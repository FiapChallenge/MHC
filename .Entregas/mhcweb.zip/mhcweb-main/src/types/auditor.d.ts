type Auditor = {
  id_auditor: number;
  nome: string;
  email: string;
  senha: string;
  cpf?: string;
  crm?: string;
  coren?: string;
  especialidade?: string;
};
