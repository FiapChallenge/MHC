type Classificacao = {
  id_classificacao?: number;
  data_hora_classificacao: string;
  gravidade_id_gravidade: number;
  sinal_id_sinal: number;
  paciente_id_paciente: number;
  auditor_id_auditor: number;
};
