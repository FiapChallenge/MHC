type Paciente = {
  id_paciente?: number;
  nome: string;
  cpf?: string;
  rg?: string;
  data_hora_entrada: string;
  data_hora_saida?: string;
  sexo?: string;
  idade?: number;
  altura?: number;
  peso?: number;
};
