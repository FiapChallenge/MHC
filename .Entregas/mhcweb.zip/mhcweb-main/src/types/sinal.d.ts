type Sinal = {
  id_sinal?: number | null;
  nome: string;
  descricao?: string;
};
